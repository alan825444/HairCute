﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace 網頁測試.Models
{
    public class 服務項目
    {
        public 服務s 服務;   
    }
   
    public class 服務s
    {
        public string 項目;
        public string 價格;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace 網頁測試.Models
{
    
    public class DataFactory
    {
        //public void Save(int ID, int DID) 
        //{
        //    var q = db.tMember.Where(m => m.fID == ID).FirstOrDefault();
        //    q.fk_Designer = DID;
        //    db.SaveChanges();
        //}

        //public void creatDSG(tDesigner m)
        //{
        //    db.tDesigner.Add(m);
        //    db.SaveChanges();
        //}

        public List<服務項目> 查詢服務項目資料(int ssID)
        {
            List<服務項目> 服務物件 = new List<服務項目>();
            demodbEntities db = new demodbEntities();
            var Service = db.tDesigner.Join(
                db.tService, //連結的表單
                d => d.fid,  //連結主表單的欄位
                s => s.fk_Designer, //連結附表單的欄位
                (d, s) => new //選擇的欄位
                {
                    D_ID = d.fid,
                    Servic = s.fServicN,
                    Price = s.fprice
                }).Where(ds => ds.D_ID == ssID);//搜尋條件
            if (Service != null)
            {
                foreach (var item in Service)
                {
                    服務物件.Add(new 服務項目
                    {
                        服務 = new 服務s
                        {
                            項目 = item.Servic,
                            價格 = item.Price
                        }
                    });
                }
            }
            return (服務物件);
        }
    }
}
﻿    var ssID = $("#ssid").val();
    $(document).ready(function () {
        $("#sent").click(function () { 店名與地址() });
        $("#Add").click(function () { 加入新表格() });
        $("#Servicesent").click(function () { 項目json資料組成()})
        讀取既有資料();
    })

    function 店名與地址()
    {
        var 店名 = $("#StoreN").val();
        var 地址 = $("#City option:selected").text();
        地址 += $("#Area option:selected").text();
        地址 += $("#place").val();
        console.log(`${店名},${地址}`);
        儲存店名與地址(店名,地址)
    }

    function 儲存店名與地址(店名, 地址)
    {
        $.ajax({
            url: "回傳資料測試",
            data: { "fStore": 店名, "fAddress": 地址 },
            type: "post",
            success: function (data) {
                $.each(data,function (item , value)
                {
                    console.log(value.Key);
                });
                
            }
        })
}

function 加入新表格()
{
    if ($("#Sitem tr").length < 6) {
        $("#Sitem").append($(
            "<tr><td><input type='text' name='fServicN' value=''/></td><td><input type='text' name='fPrice' value=''/></td></tr>"))
    }
    else {
        alert("最多新增五個項目");
    }
    
}

function 項目json資料組成()
{
    var result = [];
    var length = $("#Sitem tr input[name='fServicN']").length;    
    var 項目Arr = [];
    var 價格Arr = [];
    $("#Sitem input[name='fServicN']").each(function (index) {
        項目Arr.push($(this).val());
    })
    $("#Sitem input[name='fPrice']").each(function (index) {
        價格Arr.push($(this).val());
    })
    for (var i = 0; i < length; i++) {
        result.push({ "Item": 項目Arr[i], "Price": 價格Arr[i] });
    }
    /*console.log(result);*/
    /*新增服務品項(result);*/
    $.post(
        "/Home/新增服務項目",
        { "data": result },
        function (data) {
            console.log(data)
        },
        "json"
    )
}

function 新增服務品項(result) {
    console.log("test",result);
    $.ajax({
        url: "新增服務項目",
        data: { "data" : result},
        type: "post",
        dataType:"json",
        traditional: true,
        success: function (data) {
            console.log(data);  
        }
    })
}

function 讀取既有資料() {
    $.ajax({
        url: "載入服務項目",
        data: {"ssID":ssID},
        type: "get",
        traditional:true,
        success: function (data) {
            $.each(data, function (i, item) {
                console.log(item);
            })
        }
    })
}
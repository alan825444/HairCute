﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using 網頁測試.Models;
using 網頁測試.ViewModel;

namespace 網頁測試.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult ajaxtest()
        {
            Session["ID"] = 1000;
            Session["D_ID"] = 1001;
            return View();
        }
        [HttpPost]
        public ActionResult 回傳資料測試(tDesigner m)
        {
            
            string 店名 = m.fStore;
            string 地址 = m.fAddress;
            m.fk_Member = (int)Session["ID"];
            int ID = (int)Session["ID"];
            demodbEntities db = new demodbEntities();
            db.tDesigner.Add(m);
            db.SaveChanges();
            var q = db.tMember.Join(db.tDesigner, c => c.fID, k => k.fk_Member, (c, k) => new
            {
                Member = c,
                Designer = k
            }).Where(ck => ck.Member.fID == ID);
            //var q = db.tMember.Where(c => c.fID == ID);
            List<KeyValuePair<string, string>> test = new List<KeyValuePair<string, string>>();
            foreach (var item in q)
            {
                test.Add(new KeyValuePair<string, string>( item.Designer.fAddress,
                    item.Designer.fStore));
            }
            return Json(test ,JsonRequestBehavior.AllowGet);
        }

        public ActionResult 載入服務項目(int ssID)
        {
            //List<服務項目> 服務物件 = new List<服務項目>();
            //demodbEntities db = new demodbEntities();
            //var Service = db.tDesigner.Join(
            //    db.tService, //連結的表單
            //    d => d.fid,  //連結主表單的欄位
            //    s => s.fk_Designer, //連結附表單的欄位
            //    (d, s) => new //選擇的欄位
            //    {
            //        D_ID = d.fid,
            //        Servic = s.fServicN,
            //        Price = s.fprice
            //    }).Where(ds => ds.D_ID == ssID);//搜尋條件
            //if (Service != null)
            //{
            //    foreach (var item in Service)
            //    {
            //        服務物件.Add(new 服務項目
            //        {
            //            服務 = new 服務s
            //            {
            //                項目 = item.Servic,
            //                價格 = item.Price
            //            }
            //        });
            //    }
            //}
            List<服務項目> 服務物件 = new DataFactory().查詢服務項目資料(ssID);
            
            return Json(服務物件,JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult 新增服務項目(List<Service> data) 
        {
            
            
            //int 設計師ID = (int)Session["ID"];
            //demodbEntities db = new demodbEntities();
            //foreach (var item in Service)
            //{
            //    db.tService.Add(item.SV);
            //    db.SaveChanges();
            //}

            //List<服務項目> 服務物件 = new DataFactory().查詢服務項目資料(設計師ID);

            return Json(data,JsonRequestBehavior.AllowGet);
        }
    }
}
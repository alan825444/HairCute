﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace 網頁測試.ViewModel
{
    public class Service
    {

        public string Item { get; set; }
        public string Price { get; set; }
        //public tService SV { get; set; }
        //public 服務VM()
        //{
        //    this.SV = new tService();
        //}
        //public int fid 
        //{
        //    get { return this.SV.fid; }
        //    set { this.SV.fid = value; }
        //}
        //public string fServicN 
        //{
        //    get { return this.SV.fServicN; }
        //    set { this.SV.fServicN = value; }
        //}
        //public string fprice 
        //{
        //    get { return this.SV.fprice; }
        //    set { this.SV.fprice = value; }
        //}
        //public Nullable<int> fk_Designer 
        //{
        //    get { return this.SV.fk_Designer; }
        //    set { this.SV.fk_Designer = value; }
        //}
    }
}